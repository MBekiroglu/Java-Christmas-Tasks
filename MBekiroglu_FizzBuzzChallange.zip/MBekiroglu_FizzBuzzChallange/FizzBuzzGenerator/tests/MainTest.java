import org.junit.jupiter.api.Test;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

class MainTest {

    @Test
    void main() {
        FizzBuzzGenerator fizzBuzzGenerator = new FizzBuzzGenerator();
        List<String> List1 = new ArrayList<String>();
        Collections.addAll(List1,"1", "2", "Fizz", "4", "Buzz", "Fizz", "7", "8", "Fizz", "Buzz", "11", "Fizz", "13", "14", "FizzBuzz");
        assertEquals(List1, fizzBuzzGenerator.FizzBuzz(1,16));

        System.out.println(fizzBuzzGenerator.FizzBuzz(1,16).toString());

        assertEquals(false, fizzBuzzGenerator.divisibleBy(3,2));
    }
}

